is batting and "The bowler is bowling", respectively.Write a program to create objects of both the
Batsman and bowler classes and call the play() method for each object.'''


#Define the base class player
class player:

  def play(self):
    print("The player is playing cricket.")


#Define the derived class Batsman
class Batsman(player):

  def play(self):
    print("The batsman is batting.")


#Define the dervied class Bowler
class Bowler(player):

  def play(self):
    print("The bowler is bowling.")


#create objects of Batsman and Bowler classes
batsman = Batsman()
bowler = Bowler()

batsman.play()
bowler.play()